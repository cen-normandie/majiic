/**
 * @license Highcharts JS v9.2.2 (2021-08-24)
 * @module highcharts/modules/drilldown
 * @requires highcharts
 *
 * Highcharts Drilldown module
 *
 * Author: Torstein Honsi
 * License: www.highcharts.com/license
 *
 */
'use strict';
import '../../Extensions/Drilldown.js';
